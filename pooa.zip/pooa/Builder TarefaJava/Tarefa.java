package br.com.ucsal.model;

public class Tarefa {

    private final int id;
    private final String titulo;
    private final String descricao;
    private final Responsavel responsavel;

    // Construtor privado, usado apenas pelo Builder
    private Tarefa(Builder builder) {
        this.id = builder.id;
        this.titulo = builder.titulo;
        this.descricao = builder.descricao;
        this.responsavel = builder.responsavel;
    }

    // Getters (somente leitura, pois os setters foram removidos)
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public Responsavel getResponsavel() {
        return responsavel;
    }

    // Classe interna estática Builder
    public static class Builder {
        private int id;
        private String titulo;
        private String descricao;
        private Responsavel responsavel;

        // Métodos do Builder com encadeamento
        public Builder comId(int id) {
            this.id = id;
            return this;
        }

        public Builder comTitulo(String titulo) {
            this.titulo = titulo;
            return this;
        }

        public Builder comDescricao(String descricao) {
            this.descricao = descricao;
            return this;
        }

        public Builder comResponsavel(Responsavel responsavel) {
            this.responsavel = responsavel;
            return this;
        }

        // Método build() que retorna uma nova instância de Tarefa
        public Tarefa build() {
            return new Tarefa(this);
        }
    }
}