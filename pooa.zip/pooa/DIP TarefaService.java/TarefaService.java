package br.com.ucsal.service;

import java.util.List;
import br.com.ucsal.model.Tarefa;
import br.com.ucsal.persistencia.ITarefaPersistence;

public class TarefaService {

    private ITarefaPersistence persistence;

    // Injeção de dependência via construtor
    public TarefaService(ITarefaPersistence persistence) {
        this.persistence = persistence;
    }

    public List<Tarefa> listar() {
        return persistence.listar();
    }

    public Tarefa obterPorId(int id) {
        return persistence.obterPorId(id);
    }

    public void criar(Tarefa tarefa) {
        persistence.adcionar(tarefa);
    }

    public void atualizar(Tarefa tarefa) {
        persistence.atualizar(tarefa);
    }

    public void excluir(int id) {
        persistence.excluir(id);
    }
}