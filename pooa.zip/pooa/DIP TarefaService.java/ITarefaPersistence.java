package br.com.ucsal.persistencia;

import java.util.List;
import br.com.ucsal.model.Tarefa;

public interface ITarefaPersistence {

    List<Tarefa> listar();

    Tarefa obterPorId(int id);

    void adcionar(Tarefa tarefa);

    void atualizar(Tarefa tarefa);

    void excluir(int id);
}