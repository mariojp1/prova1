package br.com.ucsal.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.ucsal.model.Responsavel;
import br.com.ucsal.util.DatabaseUtil;

public class ResponsavelPersistence implements Persistencia<Responsavel> {

    @Override
    public List<Responsavel> listar() {
        List<Responsavel> responsaveis = new ArrayList<>();
        String query = "SELECT id, nome FROM responsavel";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Responsavel responsavel = new Responsavel(rs.getInt("id"), rs.getString("nome"));
                responsaveis.add(responsavel);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return responsaveis;
    }

    @Override
    public Responsavel obterPorId(int id) {
        String query = "SELECT id, nome FROM responsavel WHERE id = ?";
        Responsavel responsavel = null;

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    responsavel = new Responsavel(rs.getInt("id"), rs.getString("nome"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return responsavel;
    }

    @Override
    public void adcionar(Responsavel responsavel) {
        String query = "INSERT INTO responsavel (nome) VALUES (?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, responsavel.getNome());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Responsavel responsavel) {
        String query = "UPDATE responsavel SET nome = ? WHERE id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, responsavel.getNome());
            stmt.setInt(2, responsavel.getId());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void excluir(int id) {
        String query = "DELETE FROM responsavel WHERE id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}