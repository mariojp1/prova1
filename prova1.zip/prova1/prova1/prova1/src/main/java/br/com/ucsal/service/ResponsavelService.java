package br.com.ucsal.service;

import java.util.List;

import br.com.ucsal.model.Responsavel;
import br.com.ucsal.persistencia.ResponsavelPersistence;

public class ResponsavelService {

	
    private ResponsavelPersistence persistence = new ResponsavelPersistence();

    public List<Responsavel> listar() {
        return persistence.listarResponsaveis();
    }

    public Responsavel obterPorId(int id) {
        return persistence.obterResponsavelPorId(id);
    }

}
