package br.com.ucsal.persistencia;

import java.util.List;

public interface Persistencia<T> {
    List<T> listar();
    T obterPorId(int id);
    void adcionar(T entity);
    void atualizar(T entity);
    void excluir(int id);
}