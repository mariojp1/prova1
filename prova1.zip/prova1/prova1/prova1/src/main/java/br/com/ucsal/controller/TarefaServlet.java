package br.com.ucsal.controller;

import java.io.IOException;
import java.util.List;

import br.com.ucsal.model.Responsavel;
import br.com.ucsal.model.Tarefa;
import br.com.ucsal.service.ResponsavelService;
import br.com.ucsal.service.TarefaService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/TarefaServlet")
public class TarefaServlet extends HttpServlet {

    private TarefaService tarefaService = new TarefaService();
    private ResponsavelService responsavelService = new ResponsavelService();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("delete".equalsIgnoreCase(action)) {
            String idParam = request.getParameter("id");
            int id = Integer.parseInt(idParam);
            tarefaService.excluir(id);
            response.sendRedirect("TarefaServlet?action=list");
        } else if ("edit".equalsIgnoreCase(action)) {
            String idParam = request.getParameter("id");
            int id = Integer.parseInt(idParam);
            List<Responsavel> responsaveis = responsavelService.listar();
            request.setAttribute("responsaveis", responsaveis);
            Tarefa tarefa = tarefaService.obterPorId(id);
            request.setAttribute("tarefa", tarefa);
            request.getRequestDispatcher("form.jsp").forward(request, response);
        } else if ("new".equalsIgnoreCase(action)) {
            List<Responsavel> responsaveis = responsavelService.listar();
            request.setAttribute("responsaveis", responsaveis);
            request.getRequestDispatcher("form.jsp").forward(request, response);
        } else {
            List<Tarefa> tarefas = tarefaService.listar();
            request.setAttribute("tarefas", tarefas);
            request.getRequestDispatcher("list.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("create".equalsIgnoreCase(action)) {
            String titulo = request.getParameter("titulo");
            String descricao = request.getParameter("descricao");
            int responsavelId = Integer.parseInt(request.getParameter("responsavelId"));
            Tarefa tarefa = new Tarefa(0, titulo, descricao, new Responsavel(responsavelId, null));
            tarefaService.criar(tarefa);
            response.sendRedirect("TarefaServlet?action=list");

        } else if ("update".equalsIgnoreCase(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            String titulo = request.getParameter("titulo");
            String descricao = request.getParameter("descricao");
            int responsavelId = Integer.parseInt(request.getParameter("responsavelId"));
            Tarefa tarefa = new Tarefa(id, titulo, descricao, new Responsavel(responsavelId, null));
            tarefaService.atualizar(tarefa);
            response.sendRedirect("TarefaServlet?action=list");

        } else {
            response.sendRedirect("TarefaServlet?action=list");
        }
    }
}
